cc -o Advanced_Shell Advanced_Shell.c
cc -o getOrderNum getOrderNum.c
cc -o CreateMenu CreateMenu.c
cc -o MakeOrder MakeOrder.c
cc -o getPrice getPrice.c
cc -o getMenu getMenu.c
./Advanced_Shell
